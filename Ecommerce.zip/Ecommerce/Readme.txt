E richiesto almeno un server locale per il corretto funzionamento.

Come richiesto dalla consegna, tutti i prodotti sono caricati in modo dinamico dal js, e non ci sono riferimenti testuali nei file
html, ma tutti i dati dei prodotti sono contenuti in un json.


Per visualizzare le funzioni di scelta multipla di prodotti andare nella pagina prodotto di un singolo prodotto specifico,
qualora si aggiunga al carrello direttamente dall'archivio verrà inserita la versione di "base".
I prodotti che possiedono la funzionalita di scelta opzione, sono: Jagermeister, Jack Daniel's e WhisKey 10 anni.

per usufruire della funzione bundle bisogna entrare nella singola pagina di un prodotto e da li selezionare il bundle scelto.

Codici sconto:
DIVINE10
WELCOME20
FREESHIP
